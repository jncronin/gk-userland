#ifndef TR_WRAPPER_H
#define TR_WRAPPER_H

#include "glapitable.h"

void trInitDispatch( struct _glapi_table* dispatch );

#endif
