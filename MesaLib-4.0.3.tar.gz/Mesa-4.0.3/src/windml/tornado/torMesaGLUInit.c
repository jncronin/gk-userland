#include <stdio.h>

int torMesaGLUInit(void)
{
    return NULL;
}
