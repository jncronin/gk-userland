#include <stdio.h>

int torMesaUGLInit(void)
{
    return NULL;
}
